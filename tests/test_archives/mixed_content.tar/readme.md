# Test Archive Contents

This is a README file for testing archive scanning functionality.
It contains documentation and should not trigger any detections.

## Purpose

This file is part of a test archive used to verify that the scanner
can properly handle archives containing multiple files.

## Contents

- clean_file.txt: A benign text file
- malicious_file.txt: A file containing a test signature
- readme.md: This documentation file
- data.json: Sample JSON data
- script.sh: A shell script example

## Notes

All test files are safe and used only for automated testing purposes.
The "malicious" files contain test signatures only and are not actually harmful.