#!/usr/bin/env python3
"""
Test payload file for archive scanning.
This file contains a test signature that should be detected.
"""

import base64
import sys
from typing import Optional


class TestPayload:
    """
    A test class that contains encoded data.
    This is used for testing archive scanning functionality.
    """

    def __init__(self):
        # This encoded string contains the test signature
        self.encoded_data = "b3BlbmRldGVjdAo="
        self.description = "Test payload for open-detect scanning"

    def decode_data(self) -> bytes:
        """Decode the base64 encoded data."""
        return base64.b64decode(self.encoded_data)

    def get_info(self) -> dict:
        """Get information about this payload."""
        return {
            "type": "test_payload",
            "encoded": self.encoded_data,
            "description": self.description,
            "decoded_length": len(self.decode_data())
        }


def process_data(data: str) -> Optional[bytes]:
    """
    Process encoded data and return decoded bytes.

    Args:
        data: Base64 encoded string

    Returns:
        Decoded bytes or None if decoding fails
    """
    try:
        return base64.b64decode(data)
    except Exception as e:
        print(f"Error decoding data: {e}", file=sys.stderr)
        return None


def main():
    """Main function to demonstrate payload functionality."""
    payload = TestPayload()

    print("Test Payload Information:")
    print("-" * 40)

    info = payload.get_info()
    for key, value in info.items():
        print(f"{key}: {value}")

    print("\nAttempting to decode data...")
    decoded = payload.decode_data()
    print(f"Decoded successfully: {len(decoded)} bytes")

    # Additional test data containing the signature
    test_strings = [
        "b3BlbmRldGVjdAo=",
        "This is a clean string",
        "Another test with signature: b3BlbmRldGVjdAo="
    ]

    print("\nProcessing test strings:")
    for i, test_str in enumerate(test_strings, 1):
        print(f"{i}. {test_str[:50]}...")


if __name__ == "__main__":
    main()
