# Nested Archive Test

This directory contains a nested archive structure for testing.

## Contents

- inner_archive.zip: An archive file that contains malicious test signatures
- README.txt: This file (clean content)

## Purpose

This is used to test the scanner's ability to handle nested archives,
where one archive contains another archive file.

The inner archive contains files with the test signature "b3BlbmRldGVjdAo="
which should be detected when the nested archive is properly scanned.

## Testing Scenarios

1. Scan the outer archive and verify it detects the inner archive
2. Test recursive scanning to detect threats in nested archives
3. Verify proper handling of archive-within-archive structures

All files are for testing purposes only and contain safe test signatures.
